package com.Group.Artifact.controller;

import com.Group.Artifact.bean.Person;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Period;

@RestController
@RequestMapping("api")
public class ApiDemo {

    @GetMapping("/hello")
    public String hello(){
        return "Hello World!";
    }

    @GetMapping(value = "/person",produces = "application/json")
    public Person person(){
        Person person = new Person();
        person.setName("Edu");
        person.setLastName("Chavez");
        person.setAge(29);
        return person;
    }
}

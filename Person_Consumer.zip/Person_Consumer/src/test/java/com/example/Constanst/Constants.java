package com.example.Constanst;

public class Constants {
    // GET CONSTANTS
    public static final String GET_ENDPOINT ="";
    public static final String GETBYNAME_ENDPOINT ="";
    public static final String GET_PARTIAL_ENDPOINT="/api/person";
    public static final String GET_ALL_PARTIAL_ENDPOINT="/api/persons";
    public static final String GETBYNAME_PARTIAL_ENDPOINT="";
    public static final String GET_METHOD = "GET";

    public static final String GET_BODY_PARAMETER_1 = "name";
    public static final String GET_BODY_PARAMETER_2 = "lastname";
    public static final String GET_BODY_PARAMETER_3 = "age";
    public static final String GET_BODY_VALUE_1 = "Juan";
    public static final String GET_BODY_VALUE_2 = "Chavez";
    public static final int GET_BODY_VALUE_3 = 23;

    public static final String POST_METHOD = "POST";
    public static final String POST_PARTIAL_ENDPOINT="/api/insert";
    public static final String POST_BODY_PARAMETER_1 = "name";
    public static final String POST_BODY_PARAMETER_2 = "lastname";
    public static final String POST_BODY_PARAMETER_3 = "age";
    public static final String POST_BODY_VALUE_1 = "Joseph";
    public static final String POST_BODY_VALUE_2 = "Rena";
    public static final int POST_BODY_VALUE_3 = 23;
    public static final String MOCK_PORT = "8081";

    public static final String DELETE_PARTIAL_ENDPOINT="/api/person/delete/1";
    public static final String DELETE_METHOD = "DELETE";

}

package com.example.Person_Consumer.pact.consumer.POSTRequestTest;

import au.com.dius.pact.consumer.MockServer;
import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.dsl.PactDslJsonBody;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.consumer.junit5.PactConsumerTestExt;
import au.com.dius.pact.consumer.junit5.PactTestFor;
import au.com.dius.pact.model.RequestResponsePact;
import com.example.Person_Consumer.Person.Person;
import com.example.Person_Consumer.Person.PersonService;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;
import org.apache.http.util.EntityUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;

import java.util.HashMap;
import java.util.Map;

import static com.example.Constanst.Constants.*;
import static com.example.Constanst.Constants.GET_PARTIAL_ENDPOINT;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;


@ExtendWith(PactConsumerTestExt.class)
@PactTestFor(providerName = "providerPerson", port = MOCK_PORT)
public class Post {


    @Autowired
    private PersonService personService = new PersonService();

    @Pact(consumer = "Consumer_POST", provider = "providerPerson")
    public RequestResponsePact pactUserExists(PactDslWithProvider builder) {

        PactDslJsonBody bodyRequest = new PactDslJsonBody()
                .stringType(POST_BODY_PARAMETER_1, POST_BODY_VALUE_1)
                .stringType(POST_BODY_PARAMETER_2, POST_BODY_VALUE_2)
                .integerType(POST_BODY_PARAMETER_3, POST_BODY_VALUE_3);
        return builder.given("Person Insert")
                .uponReceiving("A request to /api/insert")
                .path(POST_PARTIAL_ENDPOINT)
                .method(POST_METHOD)
                .headers(headers())
                .body("{\n" +
                        "    \"name\": \"Omar\",\n" +
                        "    \"lastName\": \"Hernandez\",\n" +
                        "    \"age\": 23\n" +
                        "}")
                .willRespondWith()
                .status(200)
                .body("Value added successfully")
                .toPact();
    }

    @Test
    void testPersonName(MockServer mockServer) throws Exception {
        HttpResponse httpResponse = Request.Post(mockServer.getUrl() + POST_PARTIAL_ENDPOINT).bodyString("{\n" +
                "    \"name\": \"Omar\",\n" +
                "    \"lastName\": \"Hernandez\",\n" +
                "    \"age\": 23\n" +
                "}", ContentType.APPLICATION_JSON).execute().returnResponse();
        HttpEntity entity = httpResponse.getEntity();
        String responseString = EntityUtils.toString(entity, "UTF-8");
        assertThat(httpResponse.getStatusLine().getStatusCode(), is(equalTo(200)));
        assertThat(responseString, containsString("Value added"));
        System.out.println("RESPONSE: -------> " + responseString);
    }

    public Map<String, String> headers() {
        Map<String, String> headers = new HashedMap<>();
        headers.put("Content-Type", "application/json; charset=UTF-8");
        return headers;
    }
}

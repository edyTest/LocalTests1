package com.example.Person_Consumer.pact.consumer;

import au.com.dius.pact.consumer.*;
import au.com.dius.pact.consumer.dsl.PactDslJsonBody;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.model.RequestResponsePact;
import au.com.dius.pact.provider.spring.SpringRestPactRunner;
import com.amazonaws.HttpMethod;
import com.example.Person_Consumer.Person.Person;
import com.example.Person_Consumer.Person.PersonService;
import org.junit.Before;
import org.junit.Rule;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import scala.collection.immutable.List;

import java.util.Iterator;

import static org.junit.jupiter.api.Assertions.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ProviderContractTest {

    @Before
    public void setup(){

     }
    @Autowired
    private PersonService personService;

    @Rule
    public PactProviderRuleMk2 provider = new PactProviderRuleMk2("Artifact", "localhost", 8081, this);


    @Pact(consumer = "Consumer", provider = "Artifact")
    public RequestResponsePact pactUserExists(PactDslWithProvider builder) {
        PactDslJsonBody body= new PactDslJsonBody()
                .stringType("name","Edu")
                .stringType("lastname","Chavez")
                .integerType("age",29);

        return builder.given("User 1 exists")
                .uponReceiving("A request to /users/1")
                .path("/api/person")
                .method("GET")
                .willRespondWith()
                .status(200)
                .body(body)
                .toPact();
    }

    @Test
    @PactVerification(value = "Artifact")
    public void userExists() {
            PactConsumerConfig.config().put("pactRootDir", "/Users/eduardochavez/Documents/IntelliJ Proyectos/Person_Consumer/build/pacts");


        System.out.println("PACT ROOT DIR---->"+PactConsumerConfig.config().get("pactRootDir"));

        Person person = personService.getPersonDetail();
        assertEquals(person.getName(), "Edu");
    }


}

package com.example.Person_Consumer.pact.consumer.FAILURERequestTest;

import au.com.dius.pact.consumer.MockServer;
import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.consumer.junit5.PactConsumerTestExt;
import au.com.dius.pact.consumer.junit5.PactTestFor;
import au.com.dius.pact.model.RequestResponsePact;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;
import org.apache.http.util.EntityUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import java.util.Map;
import static com.example.Constanst.Constants.*;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;

@ExtendWith(PactConsumerTestExt.class)
@PactTestFor(providerName = PROVIDER_PACT_NAME, port = MOCK_PORT)
public class Post_BadRequest {

    @Pact(consumer = "Consumer_POST_BAD_REQUEST", provider = PROVIDER_PACT_NAME)
    public RequestResponsePact pactBadRequest(PactDslWithProvider builder) {

        return builder.given("Bad request")
                .uponReceiving("A bad request")
                .path(POST_PARTIAL_ENDPOINT)
                .method(POST_METHOD)
                .headers(headers())
                .body("")
                .willRespondWith()
                .headers(headersTextPlain())
                .status(BAD_REQUEST)
                .body("HTTP Status 400 – Bad Request")
                .toPact();
    }

    @Test
    void testPersonName(MockServer mockServer) throws Exception {
        HttpResponse httpResponse = Request.Post(mockServer.getUrl() + POST_PARTIAL_ENDPOINT)
                .bodyString("", ContentType.APPLICATION_JSON).execute().returnResponse();
        HttpEntity entity = httpResponse.getEntity();
        String responseString = EntityUtils.toString(entity, "UTF-8");

        assertThat(httpResponse.getStatusLine().getStatusCode(), is(equalTo(BAD_REQUEST)));
        assertThat(responseString, containsString("HTTP Status 400"));
        assertThat(responseString, containsString("Bad Request"));
        System.out.println("RESPONSE: -------> " + responseString);
    }

    public Map<String, String> headers() {
        Map<String, String> headers = new HashedMap<>();
        headers.put("Content-Type", "application/json; charset=UTF-8");
        return headers;
    }

    public Map<String, String> headersTextPlain() {
        Map<String, String> headers = new HashedMap<>();
        headers.put("Content-Type", "text/plain;charset=UTF-8");
        return headers;
    }
}


package com.example.Person_Consumer.pact.consumer.DELETERequestTest;

import au.com.dius.pact.consumer.MockServer;
import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.consumer.junit5.PactConsumerTestExt;
import au.com.dius.pact.consumer.junit5.PactTestFor;
import au.com.dius.pact.model.RequestResponsePact;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.fluent.Request;
import org.apache.http.util.EntityUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static com.example.Constanst.Constants.*;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;

@ExtendWith(PactConsumerTestExt.class)
@PactTestFor(providerName = PROVIDER_PACT_NAME, port = MOCK_PORT)
public class Delete {

    @Pact(consumer = "Consumer_DELETE", provider = PROVIDER_PACT_NAME)
    public RequestResponsePact pactUserDelete (PactDslWithProvider builder) {

        return builder.given("Delete Person from a List")
                .uponReceiving("A request to delete a person from a list")
                .path(DELETE_PARTIAL_ENDPOINT)
                .method(DELETE_METHOD)
                .willRespondWith()
                .status(OK)
                .body("Value deleted successfully")
                .toPact();
    }

    @Test
    void testResponseCode(MockServer mockServer) throws Exception {
        HttpResponse httpResponse = Request.Delete(mockServer.getUrl() + DELETE_PARTIAL_ENDPOINT).execute().returnResponse();
        HttpEntity entity = httpResponse.getEntity();
        String responseString = EntityUtils.toString(entity, "UTF-8");
        System.out.println("RESPONSE: -----> " + responseString);
        assertThat(httpResponse.getStatusLine().getStatusCode(), is(equalTo(OK)));
    }

    @Test
    void testDeleteResponseBody(MockServer mockServer) throws Exception {
        HttpResponse httpResponse = Request.Delete(mockServer.getUrl() + DELETE_PARTIAL_ENDPOINT).execute().returnResponse();
        HttpEntity entity = httpResponse.getEntity();
        String responseString = EntityUtils.toString(entity, "UTF-8");

        assertThat(responseString, containsString("Value deleted successfully"));
        System.out.println("RESPONSE: -------> " + responseString);
    }

}

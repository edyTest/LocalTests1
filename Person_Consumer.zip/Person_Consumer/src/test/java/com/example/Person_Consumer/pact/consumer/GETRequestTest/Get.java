package com.example.Person_Consumer.pact.consumer.GETRequestTest;


import au.com.dius.pact.consumer.*;
import au.com.dius.pact.consumer.dsl.PactDslJsonBody;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.consumer.junit5.PactConsumerTestExt;
import au.com.dius.pact.consumer.junit5.PactTestFor;
import au.com.dius.pact.model.RequestResponsePact;
import com.example.Person_Consumer.Person.Person;
import com.example.Person_Consumer.Person.PersonService;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.fluent.Request;
import org.apache.http.util.EntityUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;

import static com.example.Constanst.Constants.*;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.hamcrest.CoreMatchers.containsString;

@ExtendWith(PactConsumerTestExt.class)
@PactTestFor(providerName = "providerPerson", port = MOCK_PORT)
public class Get {

    @Autowired
    private PersonService personService = new PersonService();

    @Pact(consumer = "Consumer_GET", provider = "providerPerson")
    public RequestResponsePact pactUserExists(PactDslWithProvider builder) {
        PactDslJsonBody body= new PactDslJsonBody()
                .stringType(GET_BODY_PARAMETER_1,GET_BODY_VALUE_1)
                .stringType(GET_BODY_PARAMETER_2,GET_BODY_VALUE_2)
                .integerType(GET_BODY_PARAMETER_3,GET_BODY_VALUE_3);

        return builder.given("Get Person Details")
                .uponReceiving("A request to /api/person")
                .path(GET_PARTIAL_ENDPOINT)
                .method(GET_METHOD)
                .willRespondWith()
                .status(200)
                .body(body)
                .toPact();
    }

    @Test
    void testResponseCode(MockServer mockServer) throws Exception {
        HttpResponse httpResponse = Request.Get(mockServer.getUrl() + GET_PARTIAL_ENDPOINT).execute().returnResponse();
        assertThat(httpResponse.getStatusLine().getStatusCode(), is(equalTo(200)));
    }

    @Test
    void testPersonName(MockServer mockServer) throws Exception {
        HttpResponse httpResponse = Request.Get(mockServer.getUrl() + GET_PARTIAL_ENDPOINT).execute().returnResponse();
        HttpEntity entity = httpResponse.getEntity();
        String responseString = EntityUtils.toString(entity, "UTF-8");

        Person person = personService.getPersonDetail();
        assertThat(responseString,containsString( person.getName()));
        System.out.println("RESPONSE: -------> "+responseString);
    }
}

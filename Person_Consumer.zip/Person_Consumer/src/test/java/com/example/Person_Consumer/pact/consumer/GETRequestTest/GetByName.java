package com.example.Person_Consumer.pact.consumer.GETRequestTest;

import au.com.dius.pact.consumer.MockServer;
import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.dsl.PactDslJsonBody;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.consumer.junit5.PactConsumerTestExt;
import au.com.dius.pact.consumer.junit5.PactTestFor;
import au.com.dius.pact.model.RequestResponsePact;
import com.example.Person_Consumer.Person.Person;
import com.example.Person_Consumer.Person.PersonService;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.fluent.Request;
import org.apache.http.util.EntityUtils;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.Map;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;
import static com.example.Constanst.Constants.*;

@ExtendWith(PactConsumerTestExt.class)
@PactTestFor(providerName = PROVIDER_PACT_NAME, port = MOCK_PORT)
public class GetByName {

    @Autowired
    private PersonService personService = new PersonService();

    @Pact(consumer = "Consumer_GET_BYNAME", provider = PROVIDER_PACT_NAME)
    public RequestResponsePact pactSpecificUserExists(PactDslWithProvider builder) {
        PactDslJsonBody body = new PactDslJsonBody()
                .stringType(GET_BODY_PARAMETER_1, GET_BODY_VALUE_BY_NAME)
                .stringType(GET_BODY_PARAMETER_2, GET_BODY_VALUE_2)
                .integerType(GET_BODY_PARAMETER_3, GET_BODY_VALUE_3);

        return builder.given("A request to get information of specific person")
                .uponReceiving("Searching an specific person using GET Request")
                .path(GET_BY_NAME_PARTIAL_ENDPOINT)
                .method(GET_METHOD)
                .query("name=Ivan")
                .willRespondWith()
                .status(OK)
                .body(body)
                .headers(headers())
                .toPact();
    }

    @Test
    void testResponseCode(MockServer mockServer) throws Exception {
        HttpResponse httpResponse = Request.Get(mockServer.getUrl() + GET_BY_NAME_PARTIAL_ENDPOINT + "?name=Ivan").execute().returnResponse();
        assertThat(httpResponse.getStatusLine().getStatusCode(), is(equalTo(OK)));
    }

    @Test
    void testPersonName(MockServer mockServer) throws Exception {
        HttpResponse httpResponse = Request.Get(mockServer.getUrl() + GET_BY_NAME_PARTIAL_ENDPOINT + "?name=Ivan").execute().returnResponse();
        HttpEntity entity = httpResponse.getEntity();
        String responseString = EntityUtils.toString(entity, "UTF-8");

        Person person = personService.getPersonDetailByName("Ivan");
        assertThat(responseString, containsString(person.getName()));

        System.out.println("RESPONSE: -------> " + responseString);
    }

    @Test
    void testHeader(MockServer mockServer) throws Exception {
        HttpResponse httpResponse = Request.Get(mockServer.getUrl() + GET_BY_NAME_PARTIAL_ENDPOINT + "?name=Ivan").execute().returnResponse();
        HttpEntity entity = httpResponse.getEntity();
        String responseContentType = entity.getContentType().getValue();
        //assertThat(responseContentType,containsString("application"));
        assertThat(responseContentType,containsString("application/json"));
        System.out.println("STRING   CONTENT TYPE: ---------> "+responseContentType);

    }

    public Map<String, String> headers() {
        Map<String, String> headers = new HashedMap<>();
        headers.put("Content-Type", "application/json; charset=UTF-8");
        return headers;
    }
}

package com.example.Person_Consumer.pact.consumer.GETRequestTest;

import au.com.dius.pact.consumer.MockServer;
import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.dsl.PactDslJsonBody;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.consumer.junit5.PactConsumerTestExt;
import au.com.dius.pact.consumer.junit5.PactTestFor;
import au.com.dius.pact.model.RequestResponsePact;
import com.example.Person_Consumer.Person.Person;
import com.example.Person_Consumer.Person.PersonService;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.fluent.Request;
import org.apache.http.util.EntityUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;

@ExtendWith(PactConsumerTestExt.class)
@PactTestFor(providerName = "providerPerson", port = "8081")
public class GetByName {

    @Autowired
    private PersonService personService = new PersonService();

    @Pact(consumer = "Consumer_GET_BYNAME", provider = "providerPerson")
    public RequestResponsePact pactUserExists(PactDslWithProvider builder) {
        PactDslJsonBody body= new PactDslJsonBody()
                .stringType("name","Ivan")
                .stringType("lastname","Chavez")
                .integerType("age",23);

        return builder.given("Person Exists")
                .uponReceiving("A request by name to /api/person/byname")
                .path("/api/person/byname")
                .method("GET")
                .query("name=Ivan")
                .willRespondWith()
                .status(200)
                .body(body)
                .toPact();
    }

    @Test
    void testResponseCode(MockServer mockServer) throws Exception {
        HttpResponse httpResponse = Request.Get(mockServer.getUrl() + "/api/person/byname?name=Ivan").execute().returnResponse();
        assertThat(httpResponse.getStatusLine().getStatusCode(), is(equalTo(200)));
    }

    @Test
    void testPersonName(MockServer mockServer) throws Exception {

        HttpResponse httpResponse = Request.Get(mockServer.getUrl() + "/api/person/byname?name=Ivan").execute().returnResponse();
        HttpEntity entity = httpResponse.getEntity();
        String responseString = EntityUtils.toString(entity, "UTF-8");

        Person person = personService.getPersonDetailByName("Ivan");
        System.out.println("RESPONSE: -------> "+responseString);

        assertThat(responseString,containsString(person.getName()));
    }
}

package com.example.Person_Consumer.pact.consumer.GETRequestTest;

import au.com.dius.pact.consumer.MockServer;
import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.consumer.junit5.PactConsumerTestExt;
import au.com.dius.pact.consumer.junit5.PactTestFor;
import au.com.dius.pact.model.RequestResponsePact;
import com.example.Person_Consumer.Person.Person;
import com.example.Person_Consumer.Person.PersonService;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.fluent.Request;
import org.apache.http.util.EntityUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;

import static com.example.Constanst.Constants.*;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;

@ExtendWith(PactConsumerTestExt.class)
@PactTestFor(providerName = PROVIDER_PACT_NAME, port = MOCK_PORT)
public class GetAll {

    @Autowired
    private PersonService personService = new PersonService();

    @Pact(consumer = "Consumer_GET_ALL", provider = PROVIDER_PACT_NAME)
    public RequestResponsePact pactAllUsersExists(PactDslWithProvider builder) {

               return builder.given("Get all persons Exists")
                .uponReceiving("A request to get all persons information")
                .path(GET_ALL_PARTIAL_ENDPOINT)
                .method(GET_METHOD)
                .willRespondWith()
                .status(OK)
                .body("{\n" +
                        "    \"1\": {\n" +
                        "        \"name\": \"Juan\",\n" +
                        "        \"lastName\": \"Hernandez\",\n" +
                        "        \"age\": 23\n" +
                        "    },\n" +
                        "    \"2\": {\n" +
                        "        \"name\": \"Lorena\",\n" +
                        "        \"lastName\": \"Hernandez\",\n" +
                        "        \"age\": 23\n" +
                        "    },\n" +
                        "    \"3\": {\n" +
                        "        \"name\": \"Ivan\",\n" +
                        "        \"lastName\": \"Hernandez\",\n" +
                        "        \"age\": 23\n" +
                        "    }\n" +
                        "}")
                .toPact();
    }

    @Test
    void testResponseCode(MockServer mockServer) throws Exception {
        HttpResponse httpResponse = Request.Get(mockServer.getUrl() + GET_ALL_PARTIAL_ENDPOINT).execute().returnResponse();
        assertThat(httpResponse.getStatusLine().getStatusCode(), is(equalTo(OK)));
    }

    @Test
    void testPersonName(MockServer mockServer) throws Exception {
        HttpResponse httpResponse = Request.Get(mockServer.getUrl() + GET_ALL_PARTIAL_ENDPOINT).execute().returnResponse();
        HttpEntity entity = httpResponse.getEntity();
        String responseString = EntityUtils.toString(entity, "UTF-8");

        Person person = personService.getPersonDetail();
        assertThat(responseString,containsString( person.getName()));
        System.out.println("RESPONSE: -------> "+responseString);
    }
}

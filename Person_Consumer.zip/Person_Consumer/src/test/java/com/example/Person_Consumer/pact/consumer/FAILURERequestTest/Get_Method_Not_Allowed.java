package com.example.Person_Consumer.pact.consumer.FAILURERequestTest;

import au.com.dius.pact.consumer.MockServer;
import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.dsl.PactDslJsonBody;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.consumer.junit5.PactConsumerTestExt;
import au.com.dius.pact.consumer.junit5.PactTestFor;
import au.com.dius.pact.model.RequestResponsePact;
import com.example.Person_Consumer.Person.Person;
import com.example.Person_Consumer.Person.PersonService;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.fluent.Request;
import org.apache.http.util.EntityUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;

import static com.example.Constanst.Constants.*;
import static com.example.Constanst.Constants.GET_PARTIAL_ENDPOINT;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;

@ExtendWith(PactConsumerTestExt.class)
@PactTestFor(providerName = PROVIDER_PACT_NAME, port = MOCK_PORT)
public class Get_Method_Not_Allowed {

    @Pact(consumer = "Consumer_GET_NOT_ALLOWED_METHOD", provider = PROVIDER_PACT_NAME)
    public RequestResponsePact pactMethodNotAllowed(PactDslWithProvider builder) {

        return builder.given("Not Allowed Method")
                .uponReceiving("A request with Method not allowed")
                .path(GET_PARTIAL_ENDPOINT)
                .method(DELETE_METHOD)
                .willRespondWith()
                .status(METHOD_NOT_ALLOWED)
                .body("HTTP Status 405 – Method Not Allowed")
                .toPact();
    }

    @Test
    void testResponseCodeWrongMethod(MockServer mockServer) throws Exception {
        HttpResponse httpResponse = Request.Delete(mockServer.getUrl() + GET_PARTIAL_ENDPOINT).execute().returnResponse();
        assertThat(httpResponse.getStatusLine().getStatusCode(), is(equalTo(METHOD_NOT_ALLOWED)));
    }

    @Test
    void testPersonName(MockServer mockServer) throws Exception {
        HttpResponse httpResponse = Request.Delete(mockServer.getUrl() + GET_PARTIAL_ENDPOINT).execute().returnResponse();
        HttpEntity entity = httpResponse.getEntity();
        String responseString = EntityUtils.toString(entity, "UTF-8");

        assertThat(responseString,containsString("HTTP Status 405"));
        System.out.println("RESPONSE: -------> "+responseString);
    }
}

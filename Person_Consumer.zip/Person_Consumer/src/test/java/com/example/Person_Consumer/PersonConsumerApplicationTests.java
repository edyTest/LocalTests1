package com.example.Person_Consumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}

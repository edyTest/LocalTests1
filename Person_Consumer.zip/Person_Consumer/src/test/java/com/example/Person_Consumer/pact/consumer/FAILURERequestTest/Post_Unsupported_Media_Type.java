package com.example.Person_Consumer.pact.consumer.FAILURERequestTest;

import au.com.dius.pact.consumer.MockServer;
import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.dsl.PactDslJsonBody;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.consumer.junit5.PactConsumerTestExt;
import au.com.dius.pact.consumer.junit5.PactTestFor;
import au.com.dius.pact.model.RequestResponsePact;
import com.example.Person_Consumer.Person.PersonService;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;
import org.apache.http.util.EntityUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Map;

import static com.example.Constanst.Constants.*;
import static com.example.Constanst.Constants.POST_PARTIAL_ENDPOINT;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;

@ExtendWith(PactConsumerTestExt.class)
@PactTestFor(providerName = PROVIDER_PACT_NAME, port = MOCK_PORT)
public class Post_Unsupported_Media_Type {

    @Pact(consumer = "Consumer_POST_UNSUPPORTED_MEDIA_TYPE", provider = PROVIDER_PACT_NAME)
    public RequestResponsePact pactUnsupportedMediaType(PactDslWithProvider builder) {

        PactDslJsonBody bodyRequest = new PactDslJsonBody()
                .stringType(POST_BODY_PARAMETER_1, POST_BODY_VALUE_1)
                .stringType(POST_BODY_PARAMETER_2, POST_BODY_VALUE_2)
                .integerType(POST_BODY_PARAMETER_3, POST_BODY_VALUE_3);


        return builder.given("Unsupported Media Type Request")
                .uponReceiving("A request with Unsupported Media Type")
                .path(POST_PARTIAL_ENDPOINT)
                .method(POST_METHOD)
                .headers(headersTextPlain())
                .body(bodyRequest)
                .willRespondWith()
                .headers(headersTextPlain())
                .status(UNSUPPORTED_MEDIA_TYPE)
                .body("HTTP Status 415 – Unsupported Media Type")
                .toPact();
    }

    @Test
    void testPersonName(MockServer mockServer) throws Exception {
        HttpResponse httpResponse = Request.Post(mockServer.getUrl() + POST_PARTIAL_ENDPOINT)
                .bodyString("{\"name\":\"Joseph\",\"age\":23,\"lastname\":\"Rena\"}", ContentType.TEXT_PLAIN).execute().returnResponse();
        HttpEntity entity = httpResponse.getEntity();
        String responseString = EntityUtils.toString(entity, "UTF-8");

        assertThat(httpResponse.getStatusLine().getStatusCode(), is(equalTo(UNSUPPORTED_MEDIA_TYPE)));
        assertThat(responseString, containsString("HTTP Status 415"));
        assertThat(responseString, containsString("Unsupported Media Type"));

        System.out.println("RESPONSE: -------> " + responseString);
    }

    public Map<String, String> headersTextPlain() {
        Map<String, String> headers = new HashedMap<>();
        headers.put("Content-Type", "text/plain");
        return headers;
    }
}

package com.example.Person_Consumer.Person;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class PersonService {
    public Person getPersonDetail(){
        return new RestTemplate().getForObject("http://localhost:8080/api/person",Person.class);

    }

}

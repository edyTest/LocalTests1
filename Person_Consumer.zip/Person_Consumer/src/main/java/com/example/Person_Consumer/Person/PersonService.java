package com.example.Person_Consumer.Person;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class PersonService {

    public Person getPersonDetail(){
        return new RestTemplate().getForObject("http://localhost:8082/api/person",Person.class);
    }

    public Person getPersonDetailByName(String name){
        return new RestTemplate().getForObject("http://localhost:8082/api/person/byname?name={name}",Person.class,name);
    }

}

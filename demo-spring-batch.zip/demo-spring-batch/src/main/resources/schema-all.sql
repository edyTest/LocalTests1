DROP TABLE persona IF EXISTS;

CREATE TABLE persona(
primer_nombre VARCHAR(20),
segundo_nombre VARCHAR(20),
telefono VARCHAR(15)
);
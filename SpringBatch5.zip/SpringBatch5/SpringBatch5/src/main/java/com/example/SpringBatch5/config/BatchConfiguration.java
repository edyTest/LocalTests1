package com.example.SpringBatch5.config;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import com.example.SpringBatch5.items.CustomProcessor;
import com.example.SpringBatch5.items.CustomReader;

@Configuration
public class BatchConfiguration {

	@Bean
	Job createJob(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
		return new JobBuilder("job", jobRepository).flow(createStep(jobRepository, transactionManager)).end().build();
	}

    @Bean
	Step createStep(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
		// TODO Auto-generated method stub
		return new StepBuilder("step", jobRepository)
				.<String,String>chunk(3,transactionManager)
				.allowStartIfComplete(true)
				.reader(new CustomReader())
				.processor(new CustomProcessor())
				.writer(null)
                .build();
	}
}

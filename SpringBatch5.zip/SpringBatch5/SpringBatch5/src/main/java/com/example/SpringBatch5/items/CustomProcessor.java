package com.example.SpringBatch5.items;

import org.springframework.batch.item.ItemProcessor;

public class CustomProcessor implements ItemProcessor<String, String>{

	@Override
	public String process(String item) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Processing data -"+item);
		item = item.toUpperCase();
		return item;
	}
	
 
}

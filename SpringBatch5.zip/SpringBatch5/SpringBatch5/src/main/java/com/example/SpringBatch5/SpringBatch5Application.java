package com.example.SpringBatch5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBatch5Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBatch5Application.class, args);
	}

}
